#include "ns.h"
#include <inc/lib.h>

#define NS_PKT_BUF_SIZE       1536
#define NS_IVALID_ARG      1
#define NS_TX_QUEUE_FULL   2
#define NS_TX_PKT_TOO_BIG  3

extern union Nsipc nsipcbuf;

void
output(envid_t ns_envid)
{
	binaryname = "ns_output";

	// LAB 6: Your code here:
	while (1) {
		// 	- read a packet from the network server

		if (ipc_recv(NULL, &nsipcbuf, NULL) != NSREQ_OUTPUT)
			continue; // ignore none output ipc

		if (nsipcbuf.pkt.jp_len > NS_PKT_BUF_SIZE) {
			cprintf("%s: output: package size too big\n", binaryname);
			continue; // ignore it - too big
		}

		//	- send the packet to the device driver
		while (sys_net_try_send((void*)nsipcbuf.pkt.jp_data, nsipcbuf.pkt.jp_len) == -NS_TX_QUEUE_FULL) {
			//sys_yield(); // go sleep - hopefully next time you wake up, the queue will have space.
		}
	}
}
