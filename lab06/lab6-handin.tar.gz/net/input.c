#include "ns.h"
#include <inc/lib.h>
#include <inc/env.h>

#define E1000_ERR_RX_QUEUE_EMPTY 5
#define BUF_SIZE 2048

extern union Nsipc nsipcbuf;

/*
	This piece of F*cking Sh*t almost made me cry
	Who the F*ck would have thought that even with yielding
	the cpu, sometimes the hint wouldn't have helped.
	F*ck this - I solve it by addeing 16 pages to work on

	F*ck 
	F*ck 
	F*ck 
	F*ck 
	F*ck 
	F*ck 
*/

void
input(envid_t ns_envid)
{
	binaryname = "ns_input";

	// LAB 6: Your code here:
	// 	- read a packet from the device driver
	//	- send it to the network server
	// Hint: When you IPC a page to the network server, it will be
	// reading from it for a while, so don't immediately receive
	// another packet in to the same physical page.
	char *bufs[16];
	char *va = (char*)0x0ffff000;
	int i;

	for (i = 0; i < 16; i++) {
		sys_page_alloc(0, va, PTE_P | PTE_U | PTE_W);
		bufs[i] = va;
		va += PGSIZE;
	}

	uint8_t buf[BUF_SIZE] = {0};
	int sys_ret = 0;
	int current_buffer = 0;

	while (1) {
		// build req
		union Nsipc *nsipc = (union Nsipc *) bufs[current_buffer];
		char *packet_buf = (nsipc->pkt).jp_data;
		// - read a packet from the device driver
		//cprintf("net/input: calling syscall net input with :( %d=buf_len %p=buf\n", BUF_SIZE, packet_buf);

		while ((sys_ret = sys_net_try_recv(packet_buf, BUF_SIZE)) == -E1000_ERR_RX_QUEUE_EMPTY) {
			// noice
		}

		//cprintf("net/input: returned from syscall net input with :( %d=buf_len %p=buf\n", BUF_SIZE, packet_buf);


		assert(sys_ret != -E1000_ERR_RX_QUEUE_EMPTY);

		if (sys_ret < 0)
			panic("%s: sys_net_try_recv returned %u\n", binaryname, sys_ret);

		(nsipc->pkt).jp_len = sys_ret;
		ipc_send(ns_envid, NSREQ_INPUT, nsipc, PTE_P | PTE_W | PTE_U);
		current_buffer = (current_buffer + 1) % 16;
		sys_yield(); // hint
		sys_yield(); // hint
		sys_yield(); // hint

		// send it to the network server - IPC
		//nsipcbuf.pkt.jp_len = sys_ret;
		//memcpy(nsipcbuf.pkt.jp_data, buf, sys_ret);
		//ipc_send(ns_envid, NSREQ_INPUT, &nsipcbuf, PTE_P | PTE_U);

		//sys_yield(); // hint
		//sys_yield(); // hint
		//sys_yield(); // hint
		//memset(buf, 0, sizeof(buf));
	}
}
