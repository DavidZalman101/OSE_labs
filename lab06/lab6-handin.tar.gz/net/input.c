#include "ns.h"
#include <inc/lib.h>
#include <inc/env.h>

#define E1000_ERR_RX_QUEUE_EMPTY 5
#define BUF_SIZE 2048

extern union Nsipc nsipcbuf;

/*
	This piece of F*cking Sh*t almost made me cry
	Who the F*ck would have thought that even with yielding
	the cpu, sometimes the hint wouldn't have helped.
	F*ck this - I solve it by addeing 16 pages to work on
*/

void
input(envid_t ns_envid)
{
	binaryname = "ns_input";

	// Map the E1000 receive buffers into out address space for Zero-copy
	char *rx_bufferes_va = (char*)USER_BUFFER_BASE;
	int ret = sys_e1000_map_buffers(rx_bufferes_va);
	if (ret < 0)
		panic("net:intput: sys_e1000_map_buffers failed");
	
	uint32_t buf_len;
	int sys_ret = 0;

	// LAB 6: Your code here:
	// 	- read a packet from the device driver
	//	- send it to the network server
	// Hint: When you IPC a page to the network server, it will be
	// reading from it for a while, so don't immediately receive
	// another packet in to the same physical page.

	while (1) {
		// Recive packet - returns buffer index, sets buf_len
		while ((sys_ret = sys_net_try_recv(&buf_len)) == -E1000_ERR_RX_QUEUE_EMPTY)
			sys_yield();

		if (sys_ret < 0)
			panic("net:input: sys_net_try_recv returned %e\n", sys_ret);

		// Get buffer containing the packet data
		int buffer_idx = sys_ret;
		char *packet_buffer = rx_bufferes_va + buffer_idx * PGSIZE;

		// Zero-Copy: The E1000 has already DMA'd the packet data
		// directly into th jp_data field (dur to the buffer offset in e1000.c)
		union Nsipc *nsipc = (union Nsipc *)packet_buffer;
		nsipc->pkt.jp_len = buf_len;

		// Send the buffer page directly to the network server (zero-copy IPC)
		ipc_send(ns_envid, NSREQ_INPUT, nsipc, PTE_P | PTE_W | PTE_U);
		int i;
		for (i = 0; i < 3; i++)
			sys_yield();

		while (sys_e1000_receive_packet_done(buffer_idx) < 0) {
			sys_yield();
		}

	}
}
